﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rime.API
{
    public class API
    {
        public static readonly string _mainNet = "https://cardano-mainnet.blockfrost.io/api/v0/";
        public static readonly string _queryToken = "mainnetqW1HNm5UljEVmlVm5Rr7hdseDMaMZccB";
    }
}
