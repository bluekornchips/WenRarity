﻿using Rime.ADO.Classes.Tokens.Rarity;

namespace Rime.ADO.Classes
{
    public class PuurrtiesRarity : Rarity
    {
        public double Background { get; set; }
        public double Eyes { get; set; }
        public double Fur { get; set; }
        public double Hands { get; set; }
        public double Hat { get; set; }
        public double Mask { get; set; }
        public double Mouth { get; set; }
        public double Outfit { get; set; }
        public double Tail { get; set; }
        public double Wings { get; set; }
    }
}
