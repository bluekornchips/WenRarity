﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rime.ADO.Classes.Tokens.Rarity
{
    public class HappyHoppersRarity : Rarity
    {
        public double Background { get; set; }
        public double Eyes { get; set; }
        public double Hands { get; set; }
        public double Hat { get; set; }
        public double Mouth { get; set; }
        public double Skin { get; set; }
        public double Wings { get; set; }

        public HappyHoppersRarity()
        {

        }
    }
}
