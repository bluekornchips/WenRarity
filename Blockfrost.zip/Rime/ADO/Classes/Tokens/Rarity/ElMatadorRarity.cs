﻿using Rime.ADO.Classes.Tokens.Rarity;

namespace Rime.ADO.Classes
{
    public class ElMatadorRarity : Rarity
    {
        public double Canvas { get; set; }
        public double Chaqueta { get; set; }
        public double Craneo { get; set; }
        public double Polvo { get; set; }
        public double Rociada { get; set; }
    }
}
