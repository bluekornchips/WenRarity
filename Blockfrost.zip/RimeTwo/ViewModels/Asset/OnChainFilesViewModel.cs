﻿namespace RimeTwo.ViewModels.Asset
{
    public class OnChainFilesViewModel
    {
        public string src { get; set; }
        public string name { get; set; }
        public string mediaType { get; set; }
    }
}
