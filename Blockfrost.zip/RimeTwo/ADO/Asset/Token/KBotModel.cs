namespace RimeTwo.ADO.Asset.Token
{
	public class KBotModel : OnChainMetaDataModel
	{
		public string Pet { get; set; }
		public string Id { get; set; }
		public string website { get; set; }
		public string copyright { get; set; }
		public string royalties { get; set; }
		public string collection { get; set; }
		public KBotModel(){ }
	}
}
