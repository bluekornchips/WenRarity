﻿namespace MarketWatcher.Classes
{
    public class CollectionData
    {
        public int CollectionSize { get; set; }
        public int Floor { get; set; }
    }
}
