﻿using MarketWatcher.Utility;

namespace MarketWatcher.API
{
    public class MarketplaceAPI
    {
        internal Ducky _ducky = Ducky.GetInstance();
    }
}
