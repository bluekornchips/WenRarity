﻿using System.Collections.Generic;

namespace MarketWatcher.Discord.Webhooks
{
    public static class Colorsss
    {
        public static Dictionary<string, string> colors = new()
        {
            { "blue", "1a50b6" },
            { "green", "0E731E" }
        };
    }
}
