﻿namespace MarketWatcher.Classes.JPGStore
{
    public class EmbedMedia
    {
        public string url { get; set; }
        public string proxyurl { get; set; }
        public int? height { get; set; }
        public int? width { get; set; }
    }
}