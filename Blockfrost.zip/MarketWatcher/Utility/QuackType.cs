﻿namespace MarketWatcher.Utility
{
    public partial class Ducky
	{
        enum QuackType
        {
			DEBUG = 3,
			ERROR = 2,
			CRITICAL = 1,
			INFO = 0
        }
	}
}
