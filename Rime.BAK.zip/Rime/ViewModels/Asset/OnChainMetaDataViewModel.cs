﻿using Rime.ADO;
using System.Collections.Generic;

namespace Rime.ViewModels.Asset
{
    public class OnChainMetaDataViewModel
    {
        public string name { get; set; }
        public string image { get; set; }
        public string mediaType { get; set; }
        public Dictionary<string, string> attributes { get; set; } = new Dictionary<string, string>();
        public List<OnChainFilesViewModel> files { get; set; }

        public OnChainMetaData AsOnChainMetaData()
        {
            OnChainMetaData onChainMetaData = new OnChainMetaData();
            onChainMetaData.name = name;
            onChainMetaData.image = image;
            onChainMetaData.mediaType = mediaType;
            return onChainMetaData;
        }
    }
}
