﻿using Rime.ADO;
using System;

namespace Rime.ViewModels.Collection
{
    internal class CollectionViewModel
    {
        public string PolicyId { get; set; }
        public string Name { get; set; }
        public Type AssetType { get; set; }

        public Collections AsCollection()
        {
            Collections model = new Collections();
            model.PolicyId = PolicyId;
            model.Name = Name;
            return model;
        }
    }
}
