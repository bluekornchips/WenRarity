﻿using Rime.ADO;
using Rime.API.Blockfrost;
using Rime.Controller;
using Rime.Utils;
using Rime.ViewModels.Asset;
using Rime.ViewModels.Collection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rime.Builders.CollectionBuilder
{
    internal class CollectionBuilder
    {
        private static CollectionBuilder _instance;
        public static CollectionBuilder Instance => _instance ?? (_instance = new CollectionBuilder());
        private static BlockfrostAPI blockfrostAPI = BlockfrostAPI.Instance;
        private static RimeController _rimeController = RimeController.Instance;
        private static Ducky _ducky = Ducky.Instance;

        private CollectionViewModel _collection = new CollectionViewModel();
        private Dictionary<string, Assets> assets = new Dictionary<string, Assets>();
        private CollectionBuilder() { }

        public bool Build(CollectionViewModel collection)
        {
            _collection = collection;
            GetAssets(collection.Name);

            bool built = false;
            bool hasAssets = true;
            int page = 1;


            do
            {
                blockfrostAPI.Assets_ByPolicy(_collection.PolicyId, page++, out List<BlockfrostPolicyItem> items);
                if (!items.Any()) hasAssets = false;
                else
                {
                    int matchCount = 0;
                    foreach (var item in items)
                    {
                    }
                }
            } while (hasAssets);

            return built;
        }

        private void GetAssets(string tableName)
        {
            assets.Clear();
            _rimeController.RetrieveAssetByPolicy(tableName);
            //_dbController.RetrieveAssetByPolicy(typeof(KBot));
        }
    }
}
