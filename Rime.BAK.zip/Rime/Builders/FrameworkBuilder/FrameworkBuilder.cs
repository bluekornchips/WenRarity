﻿using Rime.API.Blockfrost;
using Rime.Controller;
using Rime.Utils;
using Rime.ViewModels.Asset;
using Rime.ViewModels.Collection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Rime.Builders.FrameworkBuilder
{
    internal class FrameworkBuilder
    {
        private static FrameworkBuilder _instance;
        public static FrameworkBuilder Instance => _instance ?? (_instance = new FrameworkBuilder());
        private RimeWriter _rimeWriter = RimeWriter.Instance;

        private static BlockfrostAPI blockfrostAPI = BlockfrostAPI.Instance;
        private static RimeController _rimeController = RimeController.Instance;
        private static Ducky _ducky = Ducky.Instance;
        private CollectionViewModel _collection = new CollectionViewModel();
        private FrameworkBuilder() { }
        public CollectionViewModel Build(out bool builtNew)
        {
            _collection = new CollectionViewModel();
            //Console.WriteLine("Enter Policy ID: ");
            //string policyId = Console.ReadLine();

            //Console.WriteLine("Enter Collection Name: ");
            //string collectionName = Console.ReadLine();
            _collection.PolicyId = "3f00d83452b4ead45cf5e0ca811fe8da561dfc45a5e414c88c4d8759";
            string collectionName = "KBot";
            _collection.Name = collectionName;
            CreateNew(out builtNew);
            return _collection;
        }
        private void CreateNew(out bool builtNew)
        {
            builtNew = false;
            if (!_rimeController.CollectionExists(_collection.AsCollection()))
            {
                _ducky.Info($"Creating collection for {_collection.Name}");
                WriteNew(out bool wrote);
                if (!wrote)
                {
                    return;
                }
                _rimeController.AddCollection(_collection.AsCollection());
                builtNew = true;
            }
        }

        private void WriteNew(out bool wrote)
        {
            int page = 1;
            wrote = false;
            // Check the policy
            blockfrostAPI.Assets_ByPolicy(_collection.PolicyId, page, out List<BlockfrostPolicyItem> items);

            try
            {
                if (items.Any())
                {
                    // Use the first item in sequence that has a quantity greater than 0.
                    int index = 0;
                    while (items[index].Quantity == 0) ++index;
                    BlockfrostPolicyItem item = items[index];
                    blockfrostAPI.Asset_One(item.Asset, out AssetViewModel asset);
                    _rimeWriter.BuildViewModel(_collection.Name, asset);
                    _rimeWriter.BuildModel(_collection.Name, asset);
                    wrote = true;
                }
            }
            catch (Exception ex)
            {
                _ducky.Error("FrameworkBuilder", "WriteNew", ex.Message);
                _ducky.Info($"Unable to write collection {_collection.Name}.");
            }
        }
    }
}
