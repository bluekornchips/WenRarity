namespace Rime.ADO
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Assets
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        public string asset { get; set; }

        [Required]
        [StringLength(50)]
        public string policy_id { get; set; }

        [Required]
        [StringLength(50)]
        public string asset_name { get; set; }

        [Required]
        [StringLength(50)]
        public string fingerprint { get; set; }

        public int quantity { get; set; }

        [Required]
        [StringLength(50)]
        public string initial_mint_tx_hash { get; set; }

        public int mint_or_burn_count { get; set; }

        [StringLength(50)]
        public string metadata { get; set; }

        public int onchain_metadata { get; set; }
    }
}
