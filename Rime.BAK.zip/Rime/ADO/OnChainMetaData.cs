namespace Rime.ADO
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("OnChainMetaData")]
    public partial class OnChainMetaData
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string name { get; set; }

        [Required]
        public string image { get; set; }

        [Required]
        [StringLength(100)]
        public string mediaType { get; set; }

        [Required]
        [StringLength(100)]
        public string policy_id { get; set; }
    }
}
