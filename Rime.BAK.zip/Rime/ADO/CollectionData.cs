namespace Rime.ADO
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("CollectionData")]
    public partial class CollectionData
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }

        public int asset_count { get; set; }

        public int floor_overall { get; set; }

        public int sale_highest { get; set; }

        public int sale_lowest { get; set; }
    }
}
