
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 04/15/2022 16:29:41
-- Generated from EDMX file: C:\blackbox\Projects\WenRarity\Rime\ADO\Rime.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [Rime];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------


-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[Assets]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Assets];
GO
IF OBJECT_ID(N'[dbo].[CollectionData]', 'U') IS NOT NULL
    DROP TABLE [dbo].[CollectionData];
GO
IF OBJECT_ID(N'[dbo].[Collections]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Collections];
GO
IF OBJECT_ID(N'[dbo].[OnChainMetaData]', 'U') IS NOT NULL
    DROP TABLE [dbo].[OnChainMetaData];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Assets'
CREATE TABLE [dbo].[Assets] (
    [Id] int  NOT NULL,
    [asset] nvarchar(50)  NOT NULL,
    [policy_id] nvarchar(50)  NOT NULL,
    [asset_name] nvarchar(50)  NOT NULL,
    [fingerprint] nvarchar(50)  NOT NULL,
    [quantity] int  NOT NULL,
    [initial_mint_tx_hash] nvarchar(50)  NOT NULL,
    [mint_or_burn_count] int  NOT NULL,
    [metadata] nvarchar(50)  NULL,
    [onchain_metadata] int  NOT NULL
);
GO

-- Creating table 'CollectionData'
CREATE TABLE [dbo].[CollectionData] (
    [Id] int  NOT NULL,
    [asset_count] int  NOT NULL,
    [floor_overall] int  NOT NULL,
    [sale_highest] int  NOT NULL,
    [sale_lowest] int  NOT NULL
);
GO

-- Creating table 'OnChainMetaData'
CREATE TABLE [dbo].[OnChainMetaData] (
    [Id] int  NOT NULL,
    [name] nvarchar(100)  NOT NULL,
    [image] nvarchar(max)  NOT NULL,
    [mediaType] nvarchar(100)  NOT NULL,
    [policy_id] nvarchar(100)  NOT NULL
);
GO

-- Creating table 'Collections'
CREATE TABLE [dbo].[Collections] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [PolicyId] nvarchar(100)  NOT NULL,
    [Name] nvarchar(100)  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [Id] in table 'Assets'
ALTER TABLE [dbo].[Assets]
ADD CONSTRAINT [PK_Assets]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'CollectionData'
ALTER TABLE [dbo].[CollectionData]
ADD CONSTRAINT [PK_CollectionData]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'OnChainMetaData'
ALTER TABLE [dbo].[OnChainMetaData]
ADD CONSTRAINT [PK_OnChainMetaData]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Collections'
ALTER TABLE [dbo].[Collections]
ADD CONSTRAINT [PK_Collections]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------