using System.Data.Entity;

namespace Rime.ADO
{
    public partial class RimeDb : DbContext
    {
        public RimeDb()
            : base("Rime")
        {
        }

        public virtual DbSet<Assets> Assets { get; set; }
        public virtual DbSet<CollectionData> CollectionData { get; set; }
        public virtual DbSet<Collections> Collections { get; set; }
        public virtual DbSet<OnChainMetaData> OnChainMetaData { get; set; }
        public virtual DbSet<KBot> KBots { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
        }
    }
}
