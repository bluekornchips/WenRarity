﻿using Rime.Builders.CollectionBuilder;
using Rime.Builders.FrameworkBuilder;
using Rime.Utils;
using Rime.ViewModels.Collection;

namespace Rime
{
    internal class Program
    {
        private static Ducky _ducky;

        static void Main(string[] args)
        {
            Setup();

            FrameworkBuilder builder = FrameworkBuilder.Instance;

            CollectionViewModel collection = builder.Build(out bool builtNew);
            if (builtNew) return;
            CollectionBuilder collectionBuilder = CollectionBuilder.Instance;
            collectionBuilder.Build(collection);
        }
        static void Setup()
        {
            _ducky = Ducky.Instance;
        }
    }
}
