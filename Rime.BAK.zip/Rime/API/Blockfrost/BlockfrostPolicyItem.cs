﻿namespace Rime.API.Blockfrost
{
    public class BlockfrostPolicyItem
    {
        public string Asset { get; set; }
        public int Quantity { get; set; }
    }
}
