namespace Rime.ADO
{
	public partial class GrandmasterAdventurer : OnChainMetaData
	{
		public string race { get; set; }
		public string classAttr { get; set; }
		public string genre { get; set; }
		public string level { get; set; }
		public string weapon { get; set; }
		public string subrace { get; set; }
	}
}
