namespace Rime.ADO
{
	public partial class ClumsyGhosts : OnChainMetaData
	{
		public string str_id { get; set; }
		public string hat { get; set; }
		public string body { get; set; }
		public string eyes { get; set; }
		public string hands { get; set; }
		public string outfit { get; set; }
		public string project { get; set; }
		public string website { get; set; }
		public string backdrop { get; set; }
	}
}
