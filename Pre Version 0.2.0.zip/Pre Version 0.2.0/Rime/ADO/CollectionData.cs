﻿namespace Rime.ADO
{
    public partial class CollectionData
    {
        public int Id { get; set; }
        public int asset_count { get; set; }
        public int floor_overall { get; set; }
        public int sale_highest { get; set; }
        public int sale_lowest { get; set; }
    }
}
